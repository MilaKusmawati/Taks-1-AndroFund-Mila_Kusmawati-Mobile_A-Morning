package com.codeathome.il_massiveproject_daydream

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class edit_obat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_obat)
    }
}