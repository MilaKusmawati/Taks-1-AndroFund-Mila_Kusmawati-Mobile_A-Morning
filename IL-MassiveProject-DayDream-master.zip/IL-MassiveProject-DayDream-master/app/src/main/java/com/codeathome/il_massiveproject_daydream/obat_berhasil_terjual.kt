package com.codeathome.il_massiveproject_daydream

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class obat_berhasil_terjual : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_obat_berhasil_terjual)
    }
}