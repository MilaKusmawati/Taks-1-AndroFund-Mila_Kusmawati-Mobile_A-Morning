package com.example.massive

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.codeathome.il_massiveproject_daydream.R

class obat_baru : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_obat_baru)
    }
}