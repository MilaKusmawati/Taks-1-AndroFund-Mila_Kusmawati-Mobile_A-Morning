package com.codeathome.il_massiveproject_daydream

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class detail_obat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_obat)
    }
}