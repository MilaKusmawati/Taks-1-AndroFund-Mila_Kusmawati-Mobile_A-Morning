package com.example.macro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TrackingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tracking)
    }
}