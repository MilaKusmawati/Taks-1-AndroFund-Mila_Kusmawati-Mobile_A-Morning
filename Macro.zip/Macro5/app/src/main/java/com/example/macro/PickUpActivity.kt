package com.example.macro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PickUpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pick_up)
    }
}